/* TASKVIBE v12 */
let tasks = JSON.parse(localStorage.getItem('taskvibe-tasks') || '[]');
let currentView = 'list', calendarDate = new Date(), selectedCalDate = null, phIdx = 0;
let mouseX = -9999, mouseY = -9999, mouseDown = false, dragSproutTick = 0;
const W = () => Math.max(100, window.innerWidth), H = () => Math.max(100, window.innerHeight), GROUND_Y = () => H() * 0.68;
const TASK_SHAPES = ['shape-leaf', 'shape-cloud', 'shape-stone', 'shape-flower', 'shape-mushroom', 'shape-crystal'];
const SHAPE_SPRITES = { 'shape-leaf': 'sprites/fern.svg', 'shape-cloud': 'sprites/cloud.svg', 'shape-stone': 'sprites/mushroom.svg', 'shape-flower': 'sprites/flower-pink.svg', 'shape-mushroom': 'sprites/mushroom.svg', 'shape-crystal': 'sprites/flower-purple.svg' };
const placeholders = ["Plant a new task...", "What needs growing today?", "Scatter some seeds...", "Whisper to the forest...", "The creatures await...", "Nature doesn't procrastinate."];
const completionMsgs = ["The forest celebrates!", "A flower blooms!", "The woodland creatures applaud!", "Task composted!", "The oaks nod approval.", "A butterfly was born!"];
const emptyMsgs = [{ s: 'sprites/deer.svg', t: 'The forest is quiet...', u: 'Plant a task and watch it sprout!' }, { s: 'sprites/rabbit.svg', t: 'Even the bunnies nap', u: 'Add something!' }, { s: 'sprites/fox.svg', t: 'A fox watches...', u: 'Scatter some tasks.' }];
const taglines = ["Nature is working. You should too.", "Grow your tasks, grow yourself.", "The forest whispers: do the thing.", "Wild productivity, naturally."];
const EVENTS = [
    { text: "A MYSTIC WIND blows through...", type: 'wind', dur: 6000 },
    { text: "A TRAVELING MERCHANT offers wares.", type: 'visitor', dur: 8000 },
    { text: "THE MUSHROOM KING demands tribute!", type: 'royal', dur: 7000 },
    { text: "A PORTAL OPENED! Tasks exist in 47 dimensions.", type: 'portal', dur: 6000 },
    { text: "A COSMIC SQUIRREL judged you.", type: 'chaos', dur: 5000 },
    { text: "HEAVY RAIN brings growth.", type: 'storm', dur: 6000 },
    { text: "A SHOOTING STAR grants focus.", type: 'cosmic', dur: 5000 }
];
const pick = a => a[Math.floor(Math.random() * a.length)];
function genId() { return Date.now().toString(36) + Math.random().toString(36).substr(2, 5) }
function todayStr() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') }
function fmtDate(s) { if (!s) return ''; const d = new Date(s + 'T00:00:00'), m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; return m[d.getMonth()] + ' ' + d.getDate() }
function save() { localStorage.setItem('taskvibe-tasks', JSON.stringify(tasks)) }
function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML }

/* ===== LANDSCAPE CANVAS (static) ===== */
const lc = document.getElementById('landscape-canvas'), lctx = lc.getContext('2d');
let treelineSeeds1 = [], treelineSeeds2 = [], forestTrees = [], landscapeSeeded = false;

function hillY(x, baseY, amp, seed) { return baseY + Math.sin(x * 0.004 + seed) * amp * 0.5 + Math.sin(x * 0.01 + seed * 3) * amp * 0.3 + Math.sin(x * 0.002) * amp * 0.4; }

function seedLandscape() {
    const w = W(), h = H();
    treelineSeeds1 = []; treelineSeeds2 = []; forestTrees = [];
    for (let x = 0; x < w; x += 14 + Math.random() * 10)treelineSeeds1.push({ x: x / w, h: 10 + Math.random() * 18 });
    for (let x = 0; x < w; x += 12 + Math.random() * 9)treelineSeeds2.push({ x: x / w, h: 8 + Math.random() * 16 });
    for (let i = 0; i < 12; i++) { forestTrees.push({ x: Math.random() * 0.35, sz: 30 + Math.random() * 40, trunkW: 3 + Math.random() * 3 }); }
    landscapeSeeded = true;
}

function drawStaticLandscape() {
    const w = lc.width, h = lc.height, g = GROUND_Y();
    lctx.clearRect(0, 0, w, h);
    // Sky
    const sky = lctx.createLinearGradient(0, 0, 0, h * 0.6);
    sky.addColorStop(0, '#4a7c9b'); sky.addColorStop(0.3, '#6b9dba'); sky.addColorStop(0.6, '#8fbdd4'); sky.addColorStop(1, '#b8d8c8');
    lctx.fillStyle = sky; lctx.fillRect(0, 0, w, h * 4);

    // Background Mountains
    drawMountains(lctx, h * 0.28, w, 90);

    // FIX: All hills fully opaque to prevent transparency clipping
    drawHillFill(lctx, h * 0.35, 80, '#4a7a6a', 1.0, 0.3, w, h);
    drawHillFill(lctx, h * 0.40, 60, '#3d6b5a', 1.0, 0.5, w, h);

    // Treeline 1
    lctx.globalAlpha = 0.9; lctx.fillStyle = '#2d5a48';
    treelineSeeds1.forEach(t => { const base = hillY(t.x * w, h * 0.35, 80, 0.3); lctx.beginPath(); lctx.moveTo(t.x * w, base - t.h); lctx.lineTo(t.x * w - 5, base); lctx.lineTo(t.x * w + 5, base); lctx.closePath(); lctx.fill(); });

    drawHillFill(lctx, h * 0.48, 70, '#2d6840', 1.0, 0.7, w, h);
    drawHillFill(lctx, h * 0.52, 50, '#267038', 1.0, 1.0, w, h);

    // Treeline 2
    lctx.globalAlpha = 0.9; lctx.fillStyle = '#256048';
    treelineSeeds2.forEach(t => { const base = hillY(t.x * w, h * 0.52, 50, 1.0); lctx.beginPath(); lctx.moveTo(t.x * w, base - t.h); lctx.lineTo(t.x * w - 4, base); lctx.lineTo(t.x * w + 4, base); lctx.closePath(); lctx.fill(); });
    lctx.globalAlpha = 1;

    // Pond
    drawPond(lctx, w * 0.35, g - 10, w * 0.18, h * 0.03);
    // River
    lctx.save(); lctx.globalAlpha = 0.4; lctx.strokeStyle = '#3a8898'; lctx.lineWidth = 5; lctx.lineCap = 'round';
    lctx.beginPath(); lctx.moveTo(w * 0.46, g - 8); lctx.quadraticCurveTo(w * 0.58, g + 20, w * 0.7, g + 40); lctx.stroke(); lctx.restore();

    // Ground fill
    const grd = lctx.createLinearGradient(0, g - 30, 0, h);
    grd.addColorStop(0, '#2a6b32'); grd.addColorStop(0.3, '#1e5a28'); grd.addColorStop(1, '#153d1c');
    lctx.fillStyle = grd; lctx.beginPath(); lctx.moveTo(0, g);
    for (let x = 0; x <= w; x += 4) { const yo = Math.sin(x * 0.008) * 12 + Math.sin(x * 0.02) * 5 + Math.sin(x * 0.003) * 20; lctx.lineTo(x, g + yo); }
    lctx.lineTo(w, h * 4); lctx.lineTo(0, h * 4); lctx.closePath(); lctx.fill();

    // Cave
    drawNewCave(lctx, w * 0.85, g - 10);
    // Logs/Rocks/Forest
    drawLogs(lctx, w * 0.45, g + 45); drawLogs(lctx, w * 0.52, g + 50);
    drawRock(lctx, w * 0.6, g + 25, 22, 15, '#4d4d45'); drawRock(lctx, w * 0.2, g + 10, 35, 22, '#636358');
    drawForestRegion(lctx, g, w);
    drawMush(lctx, w * 0.15, g + 55, 6); drawMush(lctx, w * 0.55, g + 35, 5);
}

function drawMountains(c, by, w, mH) {
    c.globalAlpha = 1.0;
    const pks = [[0.1, 0.6], [0.25, 0.9], [0.4, 0.7], [0.55, 1], [0.7, 0.8], [0.85, 0.65], [0.95, 0.5]];
    ['#507a8a', '#406a7a', '#305a6a'].forEach((cl, ci) => {
        c.fillStyle = cl; c.beginPath(); c.moveTo(0, by + 20 * ci);
        pks.forEach(([px, ph]) => c.lineTo(px * w, by - mH * ph + ci * 25));
        c.lineTo(w, by + 20 * ci); c.lineTo(w, by + 200); c.lineTo(0, by + 200); c.closePath(); c.fill();
        if (ci === 0) { c.fillStyle = 'rgba(255,255,255,0.2)'; pks.forEach(([px, ph]) => { const t = by - mH * ph; c.beginPath(); c.moveTo(px * w, t); c.lineTo(px * w - 12, t + 15); c.lineTo(px * w + 12, t + 15); c.closePath(); c.fill(); }); }
    });
}
function drawHillFill(c, y, amp, col, op, seed, w, h) { c.globalAlpha = op; c.fillStyle = col; c.beginPath(); c.moveTo(0, y); for (let x = 0; x <= w; x += 3)c.lineTo(x, hillY(x, y, amp, seed)); c.lineTo(w, h * 4); c.lineTo(0, h * 4); c.closePath(); c.fill(); c.globalAlpha = 1; }
function drawPond(c, cx, cy, rx, ry) { c.save(); c.globalAlpha = 0.55; const pg = c.createRadialGradient(cx, cy, 0, cx, cy, rx); pg.addColorStop(0, '#3a8a9a'); pg.addColorStop(0.6, '#2a7080'); pg.addColorStop(1, '#1a5060'); c.fillStyle = pg; c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); c.fill(); c.globalAlpha = 0.12; c.fillStyle = '#fff'; for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(cx - rx * 0.3 + i * rx * 0.3, cy, 6, 2, 0.3, 0, Math.PI * 2); c.fill(); } c.restore(); }
function drawRock(c, x, y, rw, rh, col) { c.fillStyle = col; c.beginPath(); c.moveTo(x - rw / 2, y); c.quadraticCurveTo(x - rw / 2, y - rh, x - rw * 0.2, y - rh); c.quadraticCurveTo(x, y - rh - 5, x + rw * 0.3, y - rh + 2); c.quadraticCurveTo(x + rw / 2, y - rh + 5, x + rw / 2, y); c.closePath(); c.fill(); c.fillStyle = 'rgba(255,255,255,0.08)'; c.beginPath(); c.moveTo(x - rw * 0.3, y - rh + 3); c.quadraticCurveTo(x - rw * 0.1, y - rh - 2, x + rw * 0.1, y - rh + 4); c.lineTo(x - rw * 0.1, y - rh * 0.5); c.closePath(); c.fill(); }
function drawMush(c, x, y, sz) { c.fillStyle = '#c4956a'; c.fillRect(x - 1, y - sz, 2, sz); c.fillStyle = '#d44'; c.beginPath(); c.arc(x, y - sz, sz * 0.7, Math.PI, 0); c.fill(); c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.arc(x - 2, y - sz - 1, 1.5, 0, Math.PI * 2); c.fill(); c.beginPath(); c.arc(x + 2, y - sz - 2, 1, 0, Math.PI * 2); c.fill(); }
function drawNewCave(c, cx, cy) {
    c.fillStyle = '#18181e'; c.beginPath(); c.moveTo(cx - 70, cy + 40); c.lineTo(cx - 50, cy - 40); c.lineTo(cx, cy - 65); c.lineTo(cx + 50, cy - 45); c.lineTo(cx + 80, cy + 40); c.closePath(); c.fill();
    const g = c.createRadialGradient(cx, cy, 0, cx, cy, 70); g.addColorStop(0, '#050508'); g.addColorStop(1, '#18181e'); c.fillStyle = g; c.beginPath(); c.moveTo(cx - 55, cy + 40); c.lineTo(cx - 35, cy - 25); c.lineTo(cx, cy - 50); c.lineTo(cx + 35, cy - 30); c.lineTo(cx + 65, cy + 40); c.closePath(); c.fill();
    c.fillStyle = '#2a2a35';[[-25, 18], [0, 25], [25, 20]].forEach(([dx, h]) => { c.beginPath(); c.moveTo(cx + dx - 6, cy - 45); c.lineTo(cx + dx, cy - 45 + h); c.lineTo(cx + dx + 6, cy - 45); c.fill(); });
    const cols = ['#b388ff', '#ce93d8', '#80cbc4'];[[-40, 20, 0], [-15, 25, 1], [20, 22, 2], [45, 18, 0]].forEach(([dx, h, ci]) => { c.globalAlpha = 0.7; c.fillStyle = cols[ci]; c.beginPath(); c.moveTo(cx + dx, cy + 35); c.lineTo(cx + dx + 4, cy + 35 - h); c.lineTo(cx + dx + 8, cy + 35); c.fill(); }); c.globalAlpha = 1;
}
function drawLogs(c, x, y) { c.fillStyle = '#5a3d20'; c.beginPath(); c.ellipse(x, y, 30, 6, 0.1, 0, Math.PI * 2); c.fill(); c.fillStyle = '#4a2d15'; c.beginPath(); c.ellipse(x - 30, y - 1, 6, 6, 0, 0, Math.PI * 2); c.fill(); c.strokeStyle = '#6a4d30'; c.lineWidth = 0.8;[3, 5].forEach(r => { c.beginPath(); c.arc(x - 30, y - 1, r, 0, Math.PI * 2); c.stroke(); }); c.fillStyle = '#3a8a3a'; c.globalAlpha = 0.5; c.beginPath(); c.ellipse(x - 10, y - 5, 8, 3, 0, Math.PI, 0); c.fill(); c.beginPath(); c.ellipse(x + 8, y - 4, 6, 2, 0.2, Math.PI, 0); c.fill(); c.globalAlpha = 1; }
function drawForestRegion(c, g, w) {
    forestTrees.forEach(t => { const tx = t.x * w; c.fillStyle = '#4a2d15'; c.fillRect(tx - t.trunkW / 2, g + 5, t.trunkW, t.sz * 0.4);['#1a5c2a', '#1e6b30', '#227a35'].forEach((col, i) => { c.fillStyle = col; c.beginPath(); c.arc(tx, g + 5 - i * t.sz * 0.18, t.sz * 0.22 - i * 3, 0, Math.PI * 2); c.fill(); }); });
    c.fillStyle = '#1a4a20'; c.globalAlpha = 0.6; for (let x = 0; x < w * 0.35; x += 8 + Math.random() * 6) { const bh = 5 + Math.random() * 10; c.beginPath(); c.ellipse(x, g + 15, 4, bh, 0, Math.PI, 0); c.fill(); } c.globalAlpha = 1;
}

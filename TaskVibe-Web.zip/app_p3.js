
/* ===== DOM REFS ===== */
const $ = id => document.getElementById(id);
const taskInput = $('task-input'), taskDate = $('task-date'), addBtn = $('add-btn'), taskList = $('task-list'), emptyState = $('empty-state'), listView = $('list-view'), calView = $('calendar-view'), btnList = $('btn-list-view'), btnCal = $('btn-calendar-view'), calTitle = $('cal-month-title'), calGrid = $('calendar-grid'), calPrev = $('cal-prev'), calNext = $('cal-next'), dayDetail = $('day-detail'), dayTitle = $('day-detail-title'), dayTasks = $('day-detail-tasks'), closeDetail = $('close-detail'), toastBox = $('toast-container'), tagEl = $('tagline');

/* ===== PHYSICS CARD SYSTEM ===== */
let physicsCards = [], grabCard = null, grabOff = { x: 0, y: 0 }, velHistory = [];
const GRAVITY = 0.6, BOUNCE = 0.4, FRICTION = 0.98, GROUND_PAD = 60, THROW_THRESH = 5, CARD_W = 340, CARD_H = 62;

class PhysicsCard {
    constructor(el, task, origIdx, x, y) {
        this.el = el; this.task = task; this.taskId = task.id; this.origIdx = origIdx;
        this.w = el.offsetWidth || CARD_W; this.h = el.offsetHeight || CARD_H;
        this.x = x !== undefined ? x : W() / 2 - this.w / 2; this.y = y !== undefined ? y : H() / 2 - this.h / 2;
        this.vx = 0; this.vy = 0; this.grounded = false; this.rot = 0; this.rv = 0;
        el.classList.add('physics-card', 'thrown');
        el.style.position = 'fixed'; el.style.left = this.x + 'px'; el.style.top = this.y + 'px';
        el.style.width = this.w + 'px'; el.style.zIndex = '9999';
        el.style.transform = 'none';
        if (!el.parentNode || el.parentNode !== document.body) document.body.appendChild(el);
        this._sync();
    }
    update() {
        if (this.grounded) {
            if (grabCard === this) this._sync(); // Sync if grabbed
            return;
        }
        this.vy += GRAVITY; this.vx *= FRICTION; this.x += this.vx; this.y += this.vy; this.rot += this.rv; this.rv *= 0.98;
        const floor = H() - this.h - GROUND_PAD;
        if (this.y >= floor) {
            this.y = floor; this.vy *= -BOUNCE; this.vx *= 0.9; this.rv *= 0.7;
            if (Math.abs(this.vy) < 1.5) {
                this.vy = 0; this.vx *= 0.92; this.rv = 0;
                this.rot = (this.rot % 360 + 360) % 360; if (this.rot > 180) this.rot -= 360; this.rot *= 0.8;
                if (Math.abs(this.vx) < 0.3 && Math.abs(this.rot) < 2) {
                    this.grounded = true; this.rot = 0;
                    this.el.classList.remove('thrown'); this.el.classList.add('grounded');
                }
            }
        }
        if (this.x < 0) { this.x = 0; this.vx *= -0.5; } if (this.x > W() - this.w) { this.x = W() - this.w; this.vx *= -0.5; }
        this._sync();
    }
    _sync() { this.el.style.left = this.x + 'px'; this.el.style.top = this.y + 'px'; this.el.style.transform = `rotate(${this.rot}deg)`; }
    returnToList() { this.el.remove(); physicsCards = physicsCards.filter(c => c !== this); renderTasks(); }
}
function resolveCollisions() {
    for (let i = 0; i < physicsCards.length; i++) {
        const a = physicsCards[i];
        for (let j = i + 1; j < physicsCards.length; j++) {
            const b = physicsCards[j];
            const ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x); const oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
            if (ox > 0 && oy > 0) { const cx1 = a.x + a.w / 2, cx2 = b.x + b.w / 2, cy1 = a.y + a.h / 2, cy2 = b.y + b.h / 2; if (oy < ox) { const push = oy / 2 + 0.5; if (cy1 < cy2) { a.y -= push; b.y += push; } else { a.y += push; b.y -= push; } if (!a.grounded) a.vy *= -0.3; if (!b.grounded) b.vy *= -0.3; } else { const push = ox / 2 + 0.5; if (cx1 < cx2) { a.x -= push; b.x += push; } else { a.x += push; b.x -= push; } if (!a.grounded) a.vx *= -0.3; if (!b.grounded) b.vx *= -0.3; } a._sync(); b._sync(); }
        }
    }
}
function physicsLoop() { physicsCards.forEach(c => c.update()); resolveCollisions(); requestAnimationFrame(physicsLoop); }

/* ===== TASK CRUD ===== */
function addTask() {
    const text = taskInput.value.trim(); if (!text) { taskInput.classList.add('shake'); setTimeout(() => taskInput.classList.remove('shake'), 500); return; }
    const shape = pick(TASK_SHAPES); tasks.unshift({ id: genId(), text, completed: false, date: taskDate.value || null, createdAt: Date.now(), shape, style: 'normal' }); save(); taskInput.value = ''; renderTasks(); renderCal(); toast(`"${text.length > 25 ? text.slice(0, 25) + '...' : text}" sprouted!`); triggerEvt(); if (countFlora() < 17) entities.push(new FloraEntity(pick(FLORA_TYPES))); entities.push(new FaunaEntity(pick(['butterfly', 'bee'])));
}
function toggleTask(id) { const t = tasks.find(t => t.id === id); if (!t) return; t.completed = !t.completed; save(); if (t.completed) { toast(pick(completionMsgs)); confetti(); entities.push(new FaunaEntity('butterfly')); } renderTasks(); renderCal(); if (selectedCalDate) showDay(selectedCalDate); }
function toggleTaskStyle(id) { const t = tasks.find(t => t.id === id); if (!t) return; t.style = (t.style === 'fancy') ? 'normal' : 'fancy'; save(); renderTasks(); }
function deleteTask(id) { const c = document.querySelector(`[data-id="${id}"]`); if (c) { c.classList.add('task-removing'); setTimeout(() => { tasks = tasks.filter(t => t.id !== id); save(); renderTasks(); renderCal(); if (selectedCalDate) showDay(selectedCalDate); }, 500); } else { tasks = tasks.filter(t => t.id !== id); save(); renderTasks(); renderCal(); if (selectedCalDate) showDay(selectedCalDate); } }

/* ===== RENDER TASKS (GROVE VIEW - TODAY ONLY) ===== */
function renderTasks() {
    taskList.innerHTML = '';
    const ts = todayStr();
    // Filter: Show undated or today's tasks
    const visibleTasks = tasks.filter(t => !t.date || t.date === ts);

    if (!visibleTasks.length) { emptyState.classList.add('visible'); const m = pick(emptyMsgs); emptyState.querySelector('.empty-sprite').src = m.s; emptyState.querySelector('h3').textContent = m.t; emptyState.querySelector('p').textContent = m.u; return; }
    emptyState.classList.remove('visible');

    visibleTasks.forEach((task, i) => {
        const shape = task.shape || pick(TASK_SHAPES), src = SHAPE_SPRITES[shape] || 'sprites/fern.svg';
        const c = document.createElement('div'); c.className = `task-card ${shape}${task.completed ? ' completed' : ''}${task.style === 'fancy' ? ' task-fancy' : ''}`; c.dataset.id = task.id;
        // No entrance animation for completed tasks
        if (!task.completed) c.style.animationDelay = `${i * 0.06}s`;
        else c.style.animation = 'none';
        c.innerHTML = `<span class="drag-handle">&#x2807;</span><img src="${src}" class="task-shape-sprite" alt="" draggable="false"><label class="task-checkbox"><input type="checkbox" ${task.completed ? 'checked' : ''}><span class="checkmark"></span></label><span class="task-text">${esc(task.text)}</span>${task.date ? `<span class="task-date-badge">${fmtDate(task.date)}</span>` : ''}<div class="task-actions"><button class="task-style-btn" title="Toggle Style"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg></button><button class="task-delete" title="Delete"><svg width="14" height="14" viewBox="0 0 14 14"><line x1="2" y1="2" x2="12" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="12" y1="2" x2="2" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button></div>`;
        c.querySelector('input[type="checkbox"]').addEventListener('change', () => toggleTask(task.id));
        c.querySelector('.task-style-btn').addEventListener('click', e => { e.stopPropagation(); toggleTaskStyle(task.id); });
        c.querySelector('.task-delete').addEventListener('click', e => { e.stopPropagation(); deleteTask(task.id); });
        c.addEventListener('mousedown', e => {
            if (e.target.closest('.task-checkbox') || e.target.closest('.task-delete') || e.target.closest('.task-style-btn')) return;
            e.preventDefault();
            const r = c.getBoundingClientRect(); grabOff = { x: e.clientX - r.left, y: e.clientY - r.top };
            const clone = c.cloneNode(true); clone.style.position = 'fixed'; clone.style.left = r.left + 'px'; clone.style.top = r.top + 'px'; clone.style.width = r.width + 'px'; clone.style.zIndex = '9999'; clone.style.pointerEvents = 'none'; clone.classList.add('grabbed'); clone.style.animation = 'none';
            document.body.appendChild(clone);
            const pc2 = new PhysicsCard(clone, task, i, r.left, r.top); pc2.grounded = true; grabCard = pc2; physicsCards.push(pc2); velHistory = []; c.style.opacity = '0';

            const onMove = ev => { if (!grabCard) return; const nx = ev.clientX - grabOff.x, ny = ev.clientY - grabOff.y; grabCard.x = nx; grabCard.y = ny; grabCard._sync(); velHistory.push({ x: ev.clientX, y: ev.clientY, t: Date.now() }); if (velHistory.length > 8) velHistory.shift(); const cards = Array.from(taskList.children).filter(el => el !== c && !el.classList.contains('task-placeholder')); const myY = ev.clientY; let insIdx = cards.length; for (let k = 0; k < cards.length; k++) { const cr = cards[k].getBoundingClientRect(); if (myY < cr.top + cr.height / 2) { insIdx = k; break; } } const oldP = taskList.querySelector('.task-placeholder'); if (oldP) oldP.remove(); const ph = document.createElement('div'); ph.className = 'task-placeholder'; if (insIdx >= cards.length) taskList.appendChild(ph); else taskList.insertBefore(ph, cards[insIdx]); };

            const onUp = () => {
                document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); const oldP = taskList.querySelector('.task-placeholder');
                let nextElId = null;
                if (oldP) {
                    const nextEl = oldP.nextElementSibling;
                    if (nextEl) nextElId = nextEl.dataset.id;
                    oldP.remove();
                }
                if (!grabCard) return; c.style.opacity = ''; let tvx = 0, tvy = 0; if (velHistory.length >= 2) { const a = velHistory[0], b = velHistory[velHistory.length - 1], dt = Math.max(1, b.t - a.t); tvx = (b.x - a.x) / dt * 16; tvy = (b.y - a.y) / dt * 16; } const speed = Math.sqrt(tvx * tvx + tvy * tvy);

                if (speed > THROW_THRESH) {
                    // THROW
                    grabCard.vx = tvx; grabCard.vy = tvy; grabCard.rv = (tvx + tvy) * 0.3; grabCard.grounded = false; grabCard.el.classList.remove('grabbed'); grabCard.el.classList.add('thrown'); grabCard.el.style.pointerEvents = 'auto';
                    tasks = tasks.filter(t => t.id !== task.id); save(); renderTasks();
                } else {
                    // DROP
                    if (nextElId === undefined) {
                        // logic fallthrough for re-render
                    } else {
                        // Remove from current pos
                        const curIdx = tasks.findIndex(x => x.id === task.id);
                        if (curIdx > -1) tasks.splice(curIdx, 1);

                        // Find target pos
                        let targetIdx = tasks.length;
                        if (nextElId) {
                            const tIdx = tasks.findIndex(x => x.id === nextElId);
                            if (tIdx > -1) targetIdx = tIdx;
                        }
                        tasks.splice(targetIdx, 0, task);
                        save();
                    }
                    grabCard.el.remove(); physicsCards = physicsCards.filter(p => p !== grabCard); renderTasks();
                } grabCard = null;
            };
            document.addEventListener('mousemove', onMove); document.addEventListener('mouseup', onUp);
        });
        taskList.appendChild(c);
    });
}

/* ===== VIEWS & CALENDAR ===== */
function switchView(v) { currentView = v; listView.classList.toggle('active', v === 'list'); calView.classList.toggle('active', v === 'calendar'); btnList.classList.toggle('active', v === 'list'); btnCal.classList.toggle('active', v === 'calendar'); if (v === 'calendar') renderCal(); }
function renderCal() {
    const y = calendarDate.getFullYear(), m = calendarDate.getMonth(); const ms = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    calTitle.textContent = `${ms[m]} ${y}`; calGrid.querySelectorAll('.cal-cell').forEach(c => c.remove());
    const fd = new Date(y, m, 1).getDay(), dim = new Date(y, m + 1, 0).getDate(), ts = todayStr();
    for (let i = 0; i < fd; i++) { const e = document.createElement('div'); e.className = 'cal-cell empty'; calGrid.appendChild(e); }
    for (let d = 1; d <= dim; d++) {
        const ds = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`; const c = document.createElement('div'); c.className = 'cal-cell'; if (ds === ts) c.classList.add('today'); const dt = tasks.filter(t => t.date === ds); if (dt.length) c.classList.add('has-tasks'); if (selectedCalDate === ds) c.classList.add('selected');
        c.innerHTML = `<span>${d}</span>${dt.length ? `<div class="cal-task-count"><img src="sprites/fern.svg" class="cal-icon"> ${dt.length}</div>` : ''}`;
        c.addEventListener('click', () => { selectedCalDate = ds; taskDate.value = ds; renderCal(); showDay(ds); }); calGrid.appendChild(c);
    }
}
function navMonth(d) { calendarDate.setMonth(calendarDate.getMonth() + d); selectedCalDate = null; dayDetail.style.display = 'none'; renderCal(); }

/* ===== SHOW DAY (NEW WHITE BOX SIDEBAR) ===== */
function showDay(ds) {
    dayDetail.style.display = 'block';

    // Structure for the Left Side Box
    dayDetail.innerHTML = `
        <button id="close-detail" title="Close">&times;</button>
        <h3>${fmtDate(ds)}</h3>
        <input type="text" class="day-task-input" id="day-input" placeholder="Add task..." autocomplete="off">
        <div id="day-list-items"></div>
    `;

    const list = dayDetail.querySelector('#day-list-items');
    const inp = dayDetail.querySelector('#day-input');

    dayDetail.querySelector('#close-detail').addEventListener('click', () => {
        dayDetail.style.display = 'none'; selectedCalDate = null; renderCal();
    });

    const renderDayList = () => {
        list.innerHTML = '';
        const dt = tasks.filter(t => t.date === ds);
        if (!dt.length) {
            list.innerHTML = '<p style="opacity:0.6;font-size:0.9rem;text-align:center;">No tasks planned.</p>';
        } else {
            dt.forEach(t => {
                const el = document.createElement('div'); el.className = 'day-task-item';
                el.innerHTML = `<img src="${SHAPE_SPRITES[t.shape]}" alt="" draggable="false"><span style="${t.completed ? 'text-decoration:line-through;opacity:0.6' : ''}">${esc(t.text)}</span><button class="day-task-del" title="Delete">&times;</button>`;
                // Toggle completion on click
                el.addEventListener('click', () => { toggleTask(t.id); renderDayList(); });
                // Delete button
                el.querySelector('.day-task-del').addEventListener('click', (e) => {
                    e.stopPropagation();
                    tasks = tasks.filter(x => x.id !== t.id);
                    save(); renderTasks(); renderCal(); renderDayList();
                });
                list.appendChild(el);
            });
        }
    };
    renderDayList();

    inp.addEventListener('keydown', e => {
        if (e.key === 'Enter' && inp.value.trim()) {
            const text = inp.value.trim();
            tasks.unshift({ id: genId(), text, completed: false, date: ds, createdAt: Date.now(), shape: pick(TASK_SHAPES), style: 'normal' });
            save(); renderTasks(); renderCal(); renderDayList(); inp.value = '';
        }
    });

    inp.focus();
}

function toast(m) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = m; toastBox.appendChild(t); setTimeout(() => { if (t.parentNode) t.remove(); }, 3200); }

/* ===== CONFETTI ===== */
const cc = document.getElementById('confetti-canvas'), cctx = cc.getContext('2d'); let confP = [], confAnim = false;
function confetti() { const cols = ['#4ade80', '#22c55e', '#f472b6', '#fbbf24', '#fb923c', '#c084fc', '#67e8f9']; for (let i = 0; i < 50; i++)confP.push({ x: cc.width * 0.3 + Math.random() * cc.width * 0.4, y: cc.height + 10, vx: (Math.random() - 0.5) * 10, vy: -(8 + Math.random() * 12), color: pick(cols), sz: 3 + Math.random() * 7, rot: Math.random() * 360, rs: (Math.random() - 0.5) * 8, g: 0.22, op: 1, sh: ['c', 'l', 'p'][Math.floor(Math.random() * 3)] }); if (!confAnim) { confAnim = true; animConf(); } }
function animConf() { cctx.clearRect(0, 0, cc.width, cc.height); confP.forEach(p => { p.vy += p.g; p.x += p.vx; p.y += p.vy; p.rot += p.rs; p.op -= 0.009; cctx.save(); cctx.translate(p.x, p.y); cctx.rotate(p.rot * Math.PI / 180); cctx.globalAlpha = Math.max(0, p.op); cctx.fillStyle = p.color; if (p.sh === 'l') { cctx.beginPath(); cctx.ellipse(0, 0, p.sz, p.sz * 0.35, 0.3, 0, Math.PI * 2); cctx.fill(); } else if (p.sh === 'p') { cctx.beginPath(); cctx.ellipse(0, 0, p.sz * 0.8, p.sz * 0.4, 0, 0, Math.PI * 2); cctx.fill(); } else { cctx.beginPath(); cctx.arc(0, 0, p.sz * 0.4, 0, Math.PI * 2); cctx.fill(); } cctx.restore(); }); confP = confP.filter(p => p.op > 0 && p.y < cc.height + 50); if (confP.length) requestAnimationFrame(animConf); else { confAnim = false; cctx.clearRect(0, 0, cc.width, cc.height); } }

/* ===== FLIP CLOCK + VIDEO CHEERLEADER + DIALOGUE ===== */
let prevDigits = '------';
let triciaLines = [];
let triciaIdx = 0;
let dialogueEl = null;

const DEFAULT_TRICIA = ["I think I fell head over heels for snake jazz.", "Snake jazz is like the soundtrack of my life.", "Summer, your playlist is so supes shook.", "We should totally start a vibe club.", "Why does no one appreciate snake jazz like I do?", "Ugh, math class is so not my vibe.", "I swear Jerry’s bees are, like, goal energy.", "Is it weird that I think bees are aesthetic?", "Summer, let’s hit the mall after school.", "Morty, don’t trip on the halls.", "Your sweater is a whole mood.", "I could nap under those lockers forever.", "This cafeteria pizza is totally peak chaos.", "Let’s form a band called The Vibe Travelers.", "Principal is watching us like we’re some kind of documentary.", "Summer, you gotta teach me that look.", "I love deep-space fashion trends.", "Why is everyone obsessed with that alien smoothie?", "Let’s make epic our middle name.", "My hair looks terrifyingly amazing today.", "I’m like 99% sure that’s cosmic glitter in your hair.", "Summer, I stan your confidence.", "We should skateboard through the cafeteria.", "Is it lunch yet? Asking for a friend.", "I can’t even with these school hall crowds.", "Did someone remix my heart into electric pop?", "Can we just teleport this homework away?", "I think my sneakers are sentient.", "Ugh, why does geometry even exist?", "That poster is literally peak cringe.", "I’m lowkey obsessed with your sweater vibes.", "Summer, we could totally run a fashion empire.", "This class feels like a parallel dimension of boredom.", "I can’t deal with negative energy today.", "Whoops, I spilled my drink again.", "Lunch lady deserves a medal for tolerance.", "Let’s bunny-hop to freedom.", "That playlist is peak euphoria.", "Is it socially acceptable to nap in class?", "Your hair defies all physics.", "We need to redecorate this hallway.", "Bingo wings? More like bingo BEATS.", "Morty, you walk like a confused nebula.", "Summer, your aura is out of this world.", "I think I invented a new dance move.", "Why do plants judge me?", "We should totally start a fan club.", "I call first on decorating the lockers.", "That sweater could start a rebellion.", "I’m bringing snacks for universal peace.", "Brainstorming is peak chaos but I love it.", "I live for dramatic entrances.", "That poster screams existential panic.", "School hallways are, like, cosmic highways.", "I think I redefined cool today.", "Summer, your boots are legendary.", "We should totally design new uniforms.", "My hair has its own gravitational pull.", "Let’s jam to intergalactic tunes.", "I’m pretty sure a comet approves of me.", "Lunch is THE highlight of my day.", "That dance move was ultra-sick.", "I might nap between classes, just sayin’.", "Cafeteria soup tastes like misunderstood dreams.", "I think my backpack is hiding secrets.", "That poster is screaming for neon paint.", "Your vibe is cosmic perfection.", "Let’s bring back retro high-five culture.", "Morty, keep your eyes forward.", "I think I invented a new slang.", "That music deserves a standing ovation.", "You walk like mood personified.", "I could totally be a hallway ambassador.", "Why is this staircase so dramatic?", "We should wear sunglasses in class.", "School announcements should be sung.", "I think the vending machine is alive.", "That class is peak nap energy.", "Your boots are a whole mythology.", "Lunchtime feels like zen.", "I swear the chairs judge my posture.", "We need a singing anthem for lunch.", "That math problem is a conspiracy.", "I feel like a living playlist.", "You have aura like a cosmic firefly.", "Summer, let’s redesign the yearbook cover.", "That hallway light is dramatic art.", "Let’s do a fashion takeover.", "I could totally run this hallway.", "Is it break time yet?", "Your bag holds untold mysteries.", "I think I ran out of cool.", "That vibe just ascended.", "Let’s decorate the lockers with cosmic art.", "Why is history class so ancient?", "Your energy could power a nebula.", "That cafeteria table is throne material.", "I think I invented a signature walk.", "This hallway needs a soundtrack.", "Summer, let’s rule the social scene."];
async function loadTriciaLines() {
    try {
        const resp = await fetch('elements/tricia lines.txt'); if (!resp.ok) throw new Error('Fetch failed'); const text = await resp.text(); const lines = text.split(/\n\s*\n/).map(l => l.trim()).filter(l => l.length > 0); if (lines.length > 0) triciaLines = lines; else triciaLines = DEFAULT_TRICIA;
    } catch (e) { triciaLines = DEFAULT_TRICIA; }
}
function updateDialogue() { if (!dialogueEl) return; if (!triciaLines.length) triciaLines = DEFAULT_TRICIA; dialogueEl.textContent = pick(triciaLines); dialogueEl.style.animation = 'none'; void dialogueEl.offsetWidth; dialogueEl.style.animation = ''; }
function nextDialogue() { updateDialogue(); }
function initClock() {
    const widget = document.createElement('div'); widget.className = 'corner-widget';
    widget.innerHTML = `
    <div class="tricia-area">
      <div class="tricia-dialogue" id="tricia-dialogue">You got this bestie!</div>
      <video src="sprites/tricia_loop.webm" class="cheerleader-video" autoplay loop muted playsinline></video>
    </div>
    <div class="flip-clock" id="flip-clock">
      <div class="flip-digit" id="fd-h0"><div class="flip-digit-inner">0</div></div>
      <div class="flip-digit" id="fd-h1"><div class="flip-digit-inner">0</div></div>
      <span class="flip-separator">:</span>
      <div class="flip-digit" id="fd-m0"><div class="flip-digit-inner">0</div></div>
      <div class="flip-digit" id="fd-m1"><div class="flip-digit-inner">0</div></div>
      <span class="flip-separator">:</span>
      <div class="flip-digit" id="fd-s0"><div class="flip-digit-inner">0</div></div>
      <div class="flip-digit" id="fd-s1"><div class="flip-digit-inner">0</div></div>
      <span class="flip-period" id="flip-period">AM</span>
    </div>`;
    const surface = document.getElementById('surface-section'); if (surface) surface.appendChild(widget); else document.body.appendChild(widget);
    dialogueEl = document.getElementById('tricia-dialogue'); loadTriciaLines().then(() => updateDialogue()); setInterval(updateDialogue, 60000); dialogueEl.style.cursor = 'pointer'; dialogueEl.style.pointerEvents = 'auto'; dialogueEl.addEventListener('click', nextDialogue); updateFlipClock(); setInterval(updateFlipClock, 1000);
}
function updateFlipClock() {
    const now = new Date(); let h = now.getHours(), m = now.getMinutes(), s = now.getSeconds(); const period = h >= 12 ? 'PM' : 'AM'; const h12 = h % 12 || 12; const digits = String(h12).padStart(2, '0') + String(m).padStart(2, '0') + String(s).padStart(2, '0'); const ids = ['fd-h0', 'fd-h1', 'fd-m0', 'fd-m1', 'fd-s0', 'fd-s1'];
    for (let i = 0; i < 6; i++) { if (digits[i] !== prevDigits[i]) { const el = document.getElementById(ids[i]); if (el) { const inner = el.querySelector('.flip-digit-inner'); inner.textContent = digits[i]; inner.classList.remove('flipping'); void inner.offsetWidth; inner.classList.add('flipping'); } } }
    prevDigits = digits; const pEl = document.getElementById('flip-period'); if (pEl) pEl.textContent = period;
}

/* ===== RESIZE & INIT ===== */
let natureSeeded = false;
function resizeAll() {
    [nc, pc, cc, lc].forEach(c => { c.width = W(); c.height = H() }); if (!landscapeSeeded) seedLandscape(); drawStaticLandscape(); if (!natureSeeded) { seedNature(); natureSeeded = true; }
    const groundY = H() - CARD_H - GROUND_PAD; physicsCards.forEach(c => { if (c.grounded) { c.y = groundY; c._sync(); } });
}
function initToilet() {
    const toilet = document.getElementById('toilet'); const flood = document.getElementById('flood-wave'); if (!toilet || !flood) return;
    toilet.addEventListener('click', () => { flood.classList.add('active'); setTimeout(() => { physicsCards.forEach(c => c.el.remove()); physicsCards = []; grabCard = null; if (typeof entities !== 'undefined') { entities.forEach(e => e.el.remove()); entities = []; } }, 800); setTimeout(() => { flood.classList.remove('active'); }, 2200); });
}
function init() {
    tagEl.textContent = pick(taglines); taskInput.placeholder = placeholders[0];
    setInterval(() => { phIdx++; taskInput.placeholder = placeholders[phIdx % placeholders.length]; }, 4000);
    taskDate.value = todayStr(); renderTasks(); renderCal();
    resizeAll(); setTimeout(resizeAll, 200); setTimeout(resizeAll, 1000);
    window.addEventListener('resize', resizeAll); animateNature(); initMouse(); spawnInitial(); entityTimers(); tickEntities(); physicsLoop();
    addBtn.addEventListener('click', addTask); taskInput.addEventListener('keydown', e => { if (e.key === 'Enter') addTask(); });
    btnList.addEventListener('click', () => switchView('list')); btnCal.addEventListener('click', () => switchView('calendar'));
    calPrev.addEventListener('click', () => navMonth(-1)); calNext.addEventListener('click', () => navMonth(1));
    closeDetail.addEventListener('click', () => { dayDetail.style.display = 'none'; selectedCalDate = null; renderCal(); });
    window.addEventListener('keydown', e => { if (e.target === taskInput || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') return; if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) { taskInput.focus(); } });

    function initDragBack() {
        window.addEventListener('mousedown', e => {
            const cardEl = e.target.closest('.physics-card');
            if (!cardEl || (!cardEl.classList.contains('thrown') && !cardEl.classList.contains('grounded'))) return;
            const pc = physicsCards.find(p => p.el === cardEl);
            if (!pc) return;

            e.preventDefault(); e.stopPropagation(); grabCard = pc; grabCard.grounded = true; grabCard.vx = 0; grabCard.vy = 0; grabCard.el.classList.add('grabbed'); grabCard.el.classList.remove('grounded');
            const r = cardEl.getBoundingClientRect(); grabOff = { x: e.clientX - r.left, y: e.clientY - r.top }; velHistory = [];

            const onMove = ev => {
                if (!grabCard) return;
                const nx = ev.clientX - grabOff.x, ny = ev.clientY - grabOff.y;
                grabCard.x = nx; grabCard.y = ny; grabCard._sync();
                velHistory.push({ x: ev.clientX, y: ev.clientY, t: Date.now() });
                if (velHistory.length > 8) velHistory.shift();

                const listRect = taskList.getBoundingClientRect();
                if (nx + grabCard.w > listRect.left && nx < listRect.right && ny + grabCard.h > listRect.top && ny < listRect.bottom) {
                    const cards = Array.from(taskList.children).filter(el => !el.classList.contains('task-placeholder'));
                    let insIdx = cards.length;
                    for (let k = 0; k < cards.length; k++) { const cr = cards[k].getBoundingClientRect(); if (ev.clientY < cr.top + cr.height / 2) { insIdx = k; break; } }
                    const oldP = taskList.querySelector('.task-placeholder'); if (oldP) oldP.remove();
                    const ph = document.createElement('div'); ph.className = 'task-placeholder';
                    if (insIdx >= cards.length) taskList.appendChild(ph); else taskList.insertBefore(ph, cards[insIdx]);
                } else { const oldP = taskList.querySelector('.task-placeholder'); if (oldP) oldP.remove(); }
            };

            const onUp = () => {
                document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp);
                if (!grabCard) return;
                const oldP = taskList.querySelector('.task-placeholder');
                if (oldP) {
                    let dropIdx = Array.from(taskList.children).indexOf(oldP); oldP.remove();
                    if (grabCard.task) { tasks.splice(dropIdx, 0, grabCard.task); save(); renderTasks(); }
                    grabCard.el.remove(); physicsCards = physicsCards.filter(p => p !== grabCard); grabCard = null;
                } else {
                    let tvx = 0, tvy = 0; if (velHistory.length >= 2) { const a = velHistory[0], b = velHistory[velHistory.length - 1], dt = Math.max(1, b.t - a.t); tvx = (b.x - a.x) / dt * 16; tvy = (b.y - a.y) / dt * 16; }
                    grabCard.vx = tvx; grabCard.vy = tvy; grabCard.rv = (tvx + tvy) * 0.3; grabCard.grounded = false; grabCard.el.classList.remove('grabbed'); grabCard.el.classList.add('thrown');
                }
            };
            document.addEventListener('mousemove', onMove); document.addEventListener('mouseup', onUp);
        });
    }
    initClock(); initCave(); initToilet(); initDragBack(); initEvent();
}
document.addEventListener('DOMContentLoaded', init);
